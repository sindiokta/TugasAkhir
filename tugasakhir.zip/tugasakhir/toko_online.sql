-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 03 Bulan Mei 2021 pada 04.25
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_online`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_barang`
--
-- Kesalahan membaca struktur untuk tabel toko_online.tb_barang: #1932 - Table 'toko_online.tb_barang' doesn't exist in engine
-- Kesalahan membaca data untuk tabel toko_online.tb_barang: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `toko_online`.`tb_barang`' at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_invoice`
--
-- Kesalahan membaca struktur untuk tabel toko_online.tb_invoice: #1932 - Table 'toko_online.tb_invoice' doesn't exist in engine
-- Kesalahan membaca data untuk tabel toko_online.tb_invoice: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `toko_online`.`tb_invoice`' at line 1

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pesanan`
--
-- Kesalahan membaca struktur untuk tabel toko_online.tb_pesanan: #1932 - Table 'toko_online.tb_pesanan' doesn't exist in engine
-- Kesalahan membaca data untuk tabel toko_online.tb_pesanan: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `toko_online`.`tb_pesanan`' at line 1

--
-- Trigger `tb_pesanan`
--
DELIMITER $$
CREATE TRIGGER `pesanan_penjualan` AFTER INSERT ON `tb_pesanan` FOR EACH ROW BEGIN 
UPDATE tb_barang SET stok = stok-NEW.jumlah
WHERE id_brg = NEW.id_brg;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--
-- Kesalahan membaca struktur untuk tabel toko_online.tb_user: #1932 - Table 'toko_online.tb_user' doesn't exist in engine
-- Kesalahan membaca data untuk tabel toko_online.tb_user: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `toko_online`.`tb_user`' at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
